from sqlalchemy.orm import Session

from app.models.patient import Patient
from app.models.user import User


class PatientService:

    @staticmethod
    def create_patient(
        db: Session,
        user: User,
        date_of_birth,
        phone: str,
        address: str
    ):
        patient = Patient(
            user_id=user.id,
            date_of_birth=date_of_birth,
            phone=phone,
            address=address
        )

        db.add(patient)
        db.commit()
        db.refresh(patient)

        return patient